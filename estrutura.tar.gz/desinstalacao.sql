DROP TABLE plugins.tomadorsuprimento;

DROP SEQUENCE plugins.tomadorsuprimento_sequencial_seq;

DROP TABLE plugins.empauttomador;

DROP SEQUENCE plugins.empauttomador_sequencial_seq;
